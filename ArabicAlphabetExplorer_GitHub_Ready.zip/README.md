# Arabic–Persian Alphabet Explorer

A standalone full-screen `.exe` app to help you learn:
- ✅ All 4 forms of Arabic & Persian letters (Isolated, Initial, Medial, Final)
- ✅ Audio pronunciation for each letter
- ✅ Letter connection rules
- ✅ Elegant parchment-style interface

## Instructions
1. Download the `.exe`
2. Run it (no installation needed)
3. Click any letter to explore its behavior and sound

## Coming Soon
- Tracing mode
- Typing/joining trainer
- Quizzes and calligraphy view
